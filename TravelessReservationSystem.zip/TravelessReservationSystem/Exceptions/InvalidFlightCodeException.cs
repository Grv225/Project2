﻿using System;

namespace TravelessReservationSystem.Exceptions
{
    public class InvalidFlightCodeException : Exception
    {
        public InvalidFlightCodeException(string message) : base(message) { }
    }
}
