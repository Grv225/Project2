﻿using System.Collections.Generic;
using TravelessReservationSystem.Data;
using TravelessReservationSystem.Models;

namespace TravelessReservationSystem.Services
{
    public class AirportService
    {
        private readonly List<Airport> _airports;

        public AirportService()
        {
            _airports = CsvDataLoader.LoadCsvData<Airport>("TravelessReservationSystem.Resources.Data.airports.csv");
        }

        public List<Airport> GetAllAirports()
        {
            return _airports;
        }
    }
}
