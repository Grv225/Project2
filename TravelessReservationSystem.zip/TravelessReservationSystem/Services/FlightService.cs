﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TravelessReservationSystem.Data;
using TravelessReservationSystem.Models;

namespace TravelessReservationSystem.Services
{
    public class FlightService
    {
        private readonly List<Flight> _flights;

        public FlightService()
        {
            _flights = CsvDataLoader.LoadCsvData<Flight>("TravelessReservationSystem.Resources.Data.flights.csv");
        }

        public Task<List<Flight>> FindFlights(string origin, string destination, string dayOfWeek)
        {
            var results = _flights
                .Where(f => f.Origin == origin && f.Destination == destination && f.DayOfWeek == dayOfWeek)
                .ToList();

            return Task.FromResult(results);
        }

        public Task<Flight> GetFlightByCode(string flightCode)
        {
            var flight = _flights.FirstOrDefault(f => f.FlightCode == flightCode);
            return Task.FromResult(flight);
        }
    }
}
