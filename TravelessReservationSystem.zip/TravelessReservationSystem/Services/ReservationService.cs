﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TravelessReservationSystem.Models;

namespace TravelessReservationSystem.Services
{
    public class ReservationService
    {
        public Task MakeReservation(ConcreteFlight flight, string travellerName, string citizenship)
        {
            // Implement the logic to make a reservation
            return Task.CompletedTask;
        }

        public Task<List<ConcreteReservation>> FindReservations(string reservationCode, string airline, string travellerName)
        {
            // Implement the logic to find reservations
            // Return a list of reservations
            return Task.FromResult(new List<ConcreteReservation>());
        }
    }
}
