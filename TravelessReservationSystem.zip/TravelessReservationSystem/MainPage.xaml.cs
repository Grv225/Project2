﻿using Microsoft.Maui.Controls;

namespace TravelessReservationSystem
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
