﻿using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using CsvHelper;

namespace TravelessReservationSystem.Data
{
    public static class CsvDataLoader
    {
        public static List<T> LoadCsvData<T>(string resourceName)
        {
            var assembly = Assembly.GetExecutingAssembly();
            using var stream = assembly.GetManifestResourceStream(resourceName);
            using var reader = new StreamReader(stream);
            using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);

            return new List<T>(csv.GetRecords<T>());
        }
    }
}
