﻿namespace TravelessReservationSystem.Models
{
    public class ConcreteFlight : Flight
    {
        public override void DisplayFlightInfo()
        {
            Console.WriteLine($"{FlightCode} - {Airline} from {Origin} to {Destination} on {DayOfWeek} costing {Cost}");
        }
    }
}
