﻿namespace TravelessReservationSystem.Models
{
    public class ConcreteReservation : Reservation
    {
        public override void DisplayReservationInfo()
        {
            Console.WriteLine($"Reservation {ReservationCode} for {TravellerName} ({Citizenship}) - Status: {(IsActive ? "Active" : "Inactive")}");
        }
    }
}
