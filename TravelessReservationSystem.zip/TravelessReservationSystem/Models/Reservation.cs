﻿namespace TravelessReservationSystem.Models
{
    public abstract class Reservation
    {
        public string ReservationCode { get; set; }
        public string TravellerName { get; set; }
        public string Citizenship { get; set; }
        public bool IsActive { get; set; }

        public abstract void DisplayReservationInfo();
    }
}
